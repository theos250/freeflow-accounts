import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

// Mirrors the localStorage key and "company-changed" CustomEvent that
// AppSidebar already uses for its company switcher, so feature pages stay in
// sync with whatever the user picked there without prop-drilling or a full
// context provider (matches the existing use-currency.ts style in this repo).
const STORAGE_KEY = "currentCompanyId";

async function resolveInitialCompanyId(): Promise<string | null> {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return stored;
  }

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("company_members")
    .select("company:companies(id, is_default, created_at)")
    .eq("user_id", user.id)
    .eq("status", "active")
    .order("created_at", { referencedTable: "companies", ascending: true });

  const list = (data ?? [])
    .map((r) => r.company as { id: string; is_default: boolean } | null)
    .filter(Boolean) as { id: string; is_default: boolean }[];

  const active = list.find((c) => c.is_default) ?? list[0];
  if (active && typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, active.id);
  }
  return active?.id ?? null;
}

/**
 * Returns the active company id for the current user, or null while it's
 * still loading / if the user has no company yet. Feature pages should hold
 * off on fetching until this resolves, and re-fetch when it changes (the
 * company switcher dispatches "company-changed" on every switch).
 */
export function useCurrentCompanyId(): { companyId: string | null; loading: boolean } {
  const [companyId, setCompanyId] = useState<string | null>(
    typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null,
  );
  const [loading, setLoading] = useState(companyId === null);

  useEffect(() => {
    let cancelled = false;

    if (companyId === null) {
      resolveInitialCompanyId().then((id) => {
        if (!cancelled) {
          setCompanyId(id);
          setLoading(false);
        }
      });
    }

    function onChange(e: Event) {
      const detail = (e as CustomEvent<{ companyId: string }>).detail;
      if (detail?.companyId) setCompanyId(detail.companyId);
    }
    window.addEventListener("company-changed", onChange);
    return () => {
      cancelled = true;
      window.removeEventListener("company-changed", onChange);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { companyId, loading };
}
