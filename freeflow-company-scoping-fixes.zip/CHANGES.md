# types.ts correction + company-scoping fixes

## What went wrong
The `types.ts` I sent earlier hand-stubbed the transactional tables
(`invoices`, `items`, `journal_entries`, etc.) as `Record<string, unknown>`
instead of their real shape, to save time. That accidentally hid a real bug:
once `types.ts` is generated for real (this file), TypeScript correctly
flagged that 9 feature pages were still querying/inserting those tables
**without any `company_id` filter at all** — not just missing it on inserts,
but not scoping `select()` calls either. That's a functional bug, not just a
type error: under your company-scoped RLS policies, those pages would show
empty/wrong data or fail to insert once a user has more than one company (or
in some cases even with one, depending on how RLS evaluates a null filter).

## Root cause
These 9 files predate the organizations/companies refactor and were never
updated to be company-aware. There was no shared way to know "which company
is currently active" — that only existed inside `AppSidebar.tsx`'s own
switcher (localStorage key `currentCompanyId` + a `company-changed`
`CustomEvent`), and nothing else in the app read it.

## What I added
- `src/hooks/use-current-company.ts` — a small hook that reads the same
  localStorage key and listens for the same `company-changed` event
  `AppSidebar` already dispatches, so it stays in sync with the existing
  switcher without a new context provider. Falls back to querying the user's
  default/first company if nothing's stored yet (e.g. right after
  onboarding, before the sidebar has run its own effect).

## Files fixed (all 9 + 1 shared component)
Every one of these now: imports `useCurrentCompanyId`, filters its
`select()` queries with `.eq("company_id", companyId)`, includes
`company_id` in every `insert()`, waits for `companyId` to resolve before
fetching, and re-fetches when the user switches companies.

- `src/routes/_authenticated/invoices.tsx`
- `src/routes/_authenticated/expenses.tsx`
- `src/routes/_authenticated/customers.tsx`
- `src/routes/_authenticated/items.categories.tsx`
- `src/components/items-manager.tsx` (shared by the Products/Services item pages)
- `src/routes/_authenticated/accounting.chart.tsx` — also **removed** a
  legacy `seed_default_accounts` fallback that used to fire when a company
  had 0 accounts. That RPC doesn't take `company_id` and would either error
  or seed unscoped rows now that `company_id` is `NOT NULL`. It's redundant
  anyway — `create_company` already seeds a full chart of accounts per
  company on creation.
- `src/routes/_authenticated/accounting.journals.tsx`
- `src/routes/_authenticated/sales.estimates.tsx` — also removed several
  `(supabase as any)` casts that were papering over the same missing-types
  problem.
- `src/routes/_authenticated/sales.recurring.tsx` — same `as any` cleanup.
- `src/routes/_authenticated/companies.tsx` — this page (company *settings*,
  not creation) had a fallback code path that did a raw `insert` into
  `companies` with no `organization_id` if no active company existed yet.
  That path is now removed; company creation only ever happens through the
  `create_company` RPC (onboarding, or the company switcher), which sets
  `organization_id` correctly and enforces your plan's company limit. If
  this settings page ever loads with no active company, it now shows an
  error instead of silently attempting a broken insert.

## Verification
- `tsc --noEmit`: zero errors anywhere in the app **except** 8 files that
  are confirmed orphaned — not imported by any route, so dead code:
  `CompanySwitcher.tsx`, `CreateCompanyModal.tsx`, `CompaniesPage.tsx`,
  `CreateCompanyWizard.tsx`, `components/ui/company context.tsx` (the
  space-in-filename one), and 3 settings-form components
  (`invoicing-settings-form.tsx`, `notification-settings-form.tsx`,
  `workspace-settings-form.tsx`) that import a `../../hooks/useSettings`
  module that doesn't exist. I checked with `grep -rl` across every route —
  none of these are referenced anywhere live. Worth a deletion pass
  whenever you're cleaning up, but they don't affect the running app.
- `eslint`: clean except 8 pre-existing `no-explicit-any` warnings in
  `invoices.tsx` (PDF export code) and `companies.tsx` (logo URL / session
  casts) that predate this change and aren't related to company scoping —
  left alone rather than risk touching working PDF export code.
- `vite build`: full production build succeeds.

## How to apply
Same as before — extract and copy into matching paths in the repo root:
```bash
cp -r src/* /path/to/freeflow-accounts/src/
```
This overwrites `types.ts` and the 10 files above, and adds the one new hook.
No new migrations this time — this pass was frontend-only.
