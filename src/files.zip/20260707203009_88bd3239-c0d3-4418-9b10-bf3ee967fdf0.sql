-- Banking module: bank/cash/credit-card accounts, transactions (with CSV-import
-- support and categorization), transfers between own accounts, and
-- reconciliation flags.

-- 1. Account type enum -----------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.bank_account_type AS ENUM ('bank', 'cash', 'credit_card');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- 2. Bank accounts -----------------------------------------------------
CREATE TABLE public.bank_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  type public.bank_account_type NOT NULL DEFAULT 'bank',
  currency TEXT NOT NULL DEFAULT 'USD',
  account_number_last4 TEXT,
  opening_balance NUMERIC NOT NULL DEFAULT 0,
  current_balance NUMERIC NOT NULL DEFAULT 0,
  gl_account_id UUID REFERENCES public.accounts(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bank_accounts TO authenticated;
GRANT ALL ON public.bank_accounts TO service_role;
ALTER TABLE public.bank_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bank_accounts" ON public.bank_accounts FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_bank_accounts_updated BEFORE UPDATE ON public.bank_accounts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_bank_accounts_user ON public.bank_accounts(user_id);

-- 3. Transfers between the user's own accounts --------------------------
CREATE TABLE public.bank_transfers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  from_account_id UUID NOT NULL REFERENCES public.bank_accounts(id) ON DELETE CASCADE,
  to_account_id UUID NOT NULL REFERENCES public.bank_accounts(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL CHECK (amount > 0),
  transfer_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (from_account_id <> to_account_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bank_transfers TO authenticated;
GRANT ALL ON public.bank_transfers TO service_role;
ALTER TABLE public.bank_transfers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bank_transfers" ON public.bank_transfers FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_bank_transfers_user ON public.bank_transfers(user_id);

-- 4. Transactions ---------------------------------------------------------
CREATE TABLE public.bank_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  bank_account_id UUID NOT NULL REFERENCES public.bank_accounts(id) ON DELETE CASCADE,
  txn_date DATE NOT NULL DEFAULT CURRENT_DATE,
  description TEXT NOT NULL DEFAULT '',
  amount NUMERIC NOT NULL, -- positive = money in, negative = money out
  category_account_id UUID REFERENCES public.accounts(id) ON DELETE SET NULL,
  reference TEXT,
  is_transfer BOOLEAN NOT NULL DEFAULT false,
  transfer_id UUID REFERENCES public.bank_transfers(id) ON DELETE CASCADE,
  reconciled BOOLEAN NOT NULL DEFAULT false,
  reconciled_at TIMESTAMPTZ,
  import_batch TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bank_transactions TO authenticated;
GRANT ALL ON public.bank_transactions TO service_role;
ALTER TABLE public.bank_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bank_transactions" ON public.bank_transactions FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_bank_transactions_updated BEFORE UPDATE ON public.bank_transactions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_bank_transactions_account ON public.bank_transactions(bank_account_id, txn_date DESC);
CREATE INDEX idx_bank_transactions_transfer ON public.bank_transactions(transfer_id);
CREATE INDEX idx_bank_transactions_user ON public.bank_transactions(user_id);

-- 5. Keep bank_accounts.current_balance in sync with its transactions ----
CREATE OR REPLACE FUNCTION public.handle_bank_txn_balance()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.bank_accounts SET current_balance = current_balance + NEW.amount WHERE id = NEW.bank_account_id;
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.bank_account_id IS DISTINCT FROM OLD.bank_account_id THEN
      UPDATE public.bank_accounts SET current_balance = current_balance - OLD.amount WHERE id = OLD.bank_account_id;
      UPDATE public.bank_accounts SET current_balance = current_balance + NEW.amount WHERE id = NEW.bank_account_id;
    ELSIF NEW.amount IS DISTINCT FROM OLD.amount THEN
      UPDATE public.bank_accounts SET current_balance = current_balance + (NEW.amount - OLD.amount) WHERE id = NEW.bank_account_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.bank_accounts SET current_balance = current_balance - OLD.amount WHERE id = OLD.bank_account_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$function$;

CREATE TRIGGER trg_bank_txn_balance
AFTER INSERT OR UPDATE OF amount, bank_account_id OR DELETE ON public.bank_transactions
FOR EACH ROW EXECUTE FUNCTION public.handle_bank_txn_balance();

-- 6. Atomic transfer creation (writes both legs as transactions) ---------
CREATE OR REPLACE FUNCTION public.create_bank_transfer(
  _from_account_id uuid, _to_account_id uuid, _amount numeric,
  _transfer_date date DEFAULT CURRENT_DATE, _notes text DEFAULT NULL
)
 RETURNS UUID
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  uid UUID := auth.uid();
  xfer_id UUID;
  from_name TEXT;
  to_name TEXT;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF _from_account_id = _to_account_id THEN
    RAISE EXCEPTION 'Cannot transfer to the same account';
  END IF;
  IF _amount IS NULL OR _amount <= 0 THEN
    RAISE EXCEPTION 'Transfer amount must be positive';
  END IF;

  SELECT name INTO from_name FROM public.bank_accounts WHERE id = _from_account_id AND user_id = uid;
  SELECT name INTO to_name FROM public.bank_accounts WHERE id = _to_account_id AND user_id = uid;
  IF from_name IS NULL OR to_name IS NULL THEN
    RAISE EXCEPTION 'Both accounts must belong to you';
  END IF;

  INSERT INTO public.bank_transfers (user_id, from_account_id, to_account_id, amount, transfer_date, notes)
  VALUES (uid, _from_account_id, _to_account_id, _amount, _transfer_date, _notes)
  RETURNING id INTO xfer_id;

  INSERT INTO public.bank_transactions (user_id, bank_account_id, txn_date, description, amount, is_transfer, transfer_id, reconciled)
  VALUES (uid, _from_account_id, _transfer_date, 'Transfer to ' || to_name, -_amount, true, xfer_id, false);

  INSERT INTO public.bank_transactions (user_id, bank_account_id, txn_date, description, amount, is_transfer, transfer_id, reconciled)
  VALUES (uid, _to_account_id, _transfer_date, 'Transfer from ' || from_name, _amount, true, xfer_id, false);

  RETURN xfer_id;
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.create_bank_transfer(uuid, uuid, numeric, date, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_bank_transfer(uuid, uuid, numeric, date, text) TO authenticated;
